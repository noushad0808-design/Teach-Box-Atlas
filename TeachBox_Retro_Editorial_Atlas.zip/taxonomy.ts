export const territories = [
  {
    "id": "learn",
    "name": "LEARN",
    "question": "How do we build understanding that lasts?",
    "description": "Memory, retrieval, spacing, practice, metacognition and self-regulation."
  },
  {
    "id": "teach",
    "name": "TEACH",
    "question": "What should this teaching decision make possible?",
    "description": "Pedagogy, questioning, assessment, feedback and adaptation."
  },
  {
    "id": "think",
    "name": "THINK",
    "question": "What supports this explanation—and what else could explain it?",
    "description": "Reasoning, motivation, misconceptions, bias and AI literacy."
  },
  {
    "id": "language-and-ideas",
    "name": "LANGUAGE & IDEAS",
    "question": "How does language shape what we understand?",
    "description": "English, reading, writing, rhetoric, literature and communication."
  }
] as const;
export const franchises = [
  {
    "id": "f00",
    "name": "Open Editorial",
    "territory": "learn",
    "purpose": "Explain a worthwhile educational question.",
    "sequence": [
      "Question",
      "Explanation",
      "Example",
      "Implication"
    ]
  },
  {
    "id": "f01",
    "name": "Learn Smarter",
    "territory": "learn",
    "purpose": "Translate learning mechanisms into considered practice.",
    "sequence": [
      "Learner problem",
      "Mechanism",
      "Practice",
      "Limitations"
    ]
  },
  {
    "id": "f02",
    "name": "Unlearn This",
    "territory": "think",
    "purpose": "Revisit assumptions through evidence and a better model.",
    "sequence": [
      "Assumption",
      "Evidence",
      "Better model",
      "Limits",
      "Application"
    ]
  },
  {
    "id": "f03",
    "name": "Teach It Tomorrow",
    "territory": "teach",
    "purpose": "One teacher move with context, wording and adaptation.",
    "sequence": [
      "Context",
      "Teacher move",
      "Student action",
      "Look for",
      "Adaptation"
    ]
  },
  {
    "id": "f04",
    "name": "Why Does This Happen?",
    "territory": "think",
    "purpose": "Investigate mechanisms and alternative explanations.",
    "sequence": [
      "Observation",
      "Possible mechanisms",
      "Evidence",
      "Uncertainty"
    ]
  },
  {
    "id": "f05",
    "name": "Teacher Reality",
    "territory": "teach",
    "purpose": "Make professional trade-offs visible.",
    "sequence": [
      "Dilemma",
      "Competing priorities",
      "Judgement",
      "Reflection"
    ]
  },
  {
    "id": "f06",
    "name": "The Better Question",
    "territory": "think",
    "purpose": "Compare the reasoning different questions invite.",
    "sequence": [
      "Question pair",
      "Reasoning invited",
      "Responses",
      "Transfer"
    ]
  },
  {
    "id": "f07",
    "name": "Language Lab",
    "territory": "language-and-ideas",
    "purpose": "Explore language through context and short practice.",
    "sequence": [
      "Context",
      "Meaning",
      "Interpretation",
      "Practice"
    ]
  },
  {
    "id": "f08",
    "name": "Book → Classroom",
    "territory": "language-and-ideas",
    "purpose": "Attribute a book idea before considering classroom transfer.",
    "sequence": [
      "Book/source",
      "Interpretation",
      "Application",
      "Caveats"
    ]
  },
  {
    "id": "f09",
    "name": "TeachBox Lab",
    "territory": "think",
    "purpose": "Keep hypotheses, observations and interpretations separate.",
    "sequence": [
      "Question",
      "Hypothesis",
      "Method",
      "Observation",
      "Limits",
      "Decision"
    ]
  },
  {
    "id": "f10",
    "name": "One Idea, Three Ways",
    "territory": "learn",
    "purpose": "Adapt one principle meaningfully to three contexts.",
    "sequence": [
      "Shared principle",
      "Teacher",
      "Learner",
      "Adult",
      "Compare"
    ]
  },
  {
    "id": "f11",
    "name": "Evidence in Practice",
    "territory": "learn",
    "purpose": "Connect source scope to an appropriate practice decision.",
    "sequence": [
      "Question",
      "Evidence",
      "Scope",
      "Limits",
      "Application"
    ]
  },
  {
    "id": "f12",
    "name": "TeachBox Lessons",
    "territory": "teach",
    "purpose": "A complete adaptable instructional sequence.",
    "sequence": [
      "Context",
      "Objective",
      "Activate",
      "Model",
      "Practise",
      "Apply",
      "Check",
      "Adapt",
      "Reflect"
    ]
  }
] as const;
