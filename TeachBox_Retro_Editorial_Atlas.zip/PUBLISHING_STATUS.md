# Publishing status

- Build: PASS — 32 destination pages and a 404 page.
- Static checks: PASS — 799 internal links and 227 asset references resolve.
- Desktop homepage and motion switch: inspected.
- Mobile and remaining browser interactions: NOT TESTED; browser inspection was interrupted.
- New attachment/mood-board fidelity: NEEDS VERIFICATION; only the accessible workspace references were available for inspection.
- Site publication: BLOCKED. The source workflow could not connect to the Sites repository service on port 443. No saved version or successful deployment is claimed.

The existing Site identity must be retained when resuming. Do not register a replacement. Renew the short-lived source credential, run the supported source workflow from this directory, then save and privately deploy the verified source and archive.

For local review, run `node preview.mjs` and visit http://127.0.0.1:4182. To rebuild and verify, run `node build.mjs` and `node verify.mjs`. Node 24 or later is required. The ready-to-serve website is in `dist/`.
