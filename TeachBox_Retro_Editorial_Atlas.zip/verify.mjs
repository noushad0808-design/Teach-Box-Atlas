import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve('dist');const files=[];function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(p.endsWith('.html'))files.push(p)}}walk(root);
let links=0,assets=0;const errors=[];
for(const file of files){const html=fs.readFileSync(file,'utf8');assert.equal((html.match(/<h1[\s>]/g)||[]).length,1,file+' must have one h1');assert.ok(html.includes('lang="en-GB"'));assert.ok(html.includes('Skip to content'));
for(const m of html.matchAll(/(?:href|src)="(\/[^"#?]*)/g)){let target=path.join(root,m[1]);if(m[1].endsWith('/')){target=path.join(target,'index.html');links++}else assets++;if(!fs.existsSync(target))errors.push(path.relative(root,file)+' → '+m[1])}}
assert.deepEqual(errors,[]);assert.ok(files.length>=33);const index=JSON.parse(fs.readFileSync('dist/data/search.json','utf8'));assert.equal(index.filter(x=>/^\/series\/f\d\d\/$/.test(x.url)).length,13);assert.equal(index.filter(x=>/^\/atlas\/[^/]+\/$/.test(x.url)).length,4);
assert.ok(fs.readFileSync('dist/style.css','utf8').includes('@media(prefers-reduced-motion:reduce)'));
assert.equal(JSON.parse(fs.readFileSync('.openai/hosting.json','utf8')).static.directory,'dist');
console.log(JSON.stringify({result:'PASS',htmlPages:files.length,internalLinks:links,assetReferences:assets,series:13,territories:4,checks:['single main heading','British English locale','skip navigation','all internal links and assets resolve','all series and territory routes','reduced-motion stylesheet','static hosting manifest']}));
