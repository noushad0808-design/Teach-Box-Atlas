# TeachBox — The Retro Editorial Atlas

An illustrated educational publishing website with 32 destination pages, four knowledge territories, thirteen editorial franchises and specialist experiences.

Run `node build.mjs`, `node verify.mjs`, then `node preview.mjs`. The local preview uses port 4182. All production files live in `dist/`; no package installation is required. Node 24 or later is used for the typed taxonomy module.

Interactive features include directory search, series filters, an editable learning brief with copy fallback, a PLAY commitment/reveal/transfer activity, keyboard-accessible Knowledge Desk tabs, Thought Pebble journey controls, workshop enquiry themes, and parallax with reduced-motion support. The motion preference stays in browser session storage. The site does not send form responses to a backend.

Brand marks and illustrations were taken from accessible workspace assets. The parent, Desk, PLAY, digest, Lessons and Pebble reference boards were visually inspected. These raster extractions are not represented as exact vector masters. The new hero was generated for this build. The eight newer attachment identifiers supplied in this conversation were not available as readable image bytes, so fidelity to those versions and the new mood boards is unverified.

## Publication and QA

No publication history, downloadable collection, scheduled workshop, research finding or testimonial has been invented. The notebook contains explicitly labelled editorial thought exercises. The PLAY poll is explicitly an illustrative scenario.

Build and static route/asset checks passed. Desktop homepage rendering and the motion toggle were inspected through the local browser. Further browser testing was interrupted by the browser reporting that its requirements could not be read; mobile rendering, PLAY interaction, copy behaviour, search, filters and specialist control interactions remain NOT TESTED in the browser.

The Site identity is stored in `.openai/hosting.json`. Publishing uses the supported Sites source workflow and the same project ID. Credentials must not be saved in files.
